module.exports={

	bowl6:function (what) {
	    var fullOf=what;
	    this.show=function() {
	        console.log("bowl6 of "+fullOf);
	    };
	},

	bowl7:function (what) {
	    var fullOf=what;
	    this.show=function() {
	        console.log("bowl7 of "+fullOf);
	    };
	}

};