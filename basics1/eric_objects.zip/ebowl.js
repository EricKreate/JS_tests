var eBowl=function (what) {
    var fullOf=what;
    this.show=function() {
        console.log("bowl5 of "+fullOf);
    };
};

module.exports=eBowl;